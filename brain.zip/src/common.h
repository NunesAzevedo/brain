#ifndef COMMON_H
#define COMMON_H

void printaErro(char *);
void printaFalha();
void printaComeco(char *);
void printBreakpoint();

#endif // COMMON_H