#ifndef CIRCUITOS_H
#define CIRCUITOS_H

#include "arvore_bin.h"

float and2(No *);
float or2(No *);
float xor2(No *);
float not2(No *);
void input1(No *, float);

#endif // CIRCUITOS_H